/*
Exercise 1-7. Write a program to print the value of EOF.
*/

#include <stdio.h>

int main (void){

    printf ("EOF: %d\n",EOF);
}
