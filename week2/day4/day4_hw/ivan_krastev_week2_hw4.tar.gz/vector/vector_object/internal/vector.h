#ifndef _VECTOR_
#define _VECTOR_

struct vector {
	int N;
	double *components;
};
typedef struct vector vector;

#endif
